<?php
// ─── Mock Data ────────────────────────────────────────────────

function get_stats() {
    return [
        'total_mahasiswa' => 1248,
        'mahasiswa_aktif' => 1064,
        'mahasiswa_cuti'  => 48,
        'mahasiswa_lulus' => 112,
        'mahasiswa_do'    => 24,
        'total_dosen'     => 87,
        'dosen_aktif'     => 72,
        'total_praktik'   => 34,
        'praktik_aktif'   => 28,
        'mahasiswa_praktik' => 412,
        'pendapatan_bulan' => '4,2M',
        'pendapatan_tahun' => '24,8M',
        'pengeluaran_tahun'=> '18,3M',
        'saldo_bersih'     => '6,5M',
    ];
}

function get_mahasiswa($filter = 'semua') {
    $data = [
        ['no'=>1, 'inisial'=>'AN', 'nama'=>'Anisa Nurhayati',  'nim'=>'2021.01.042', 'prodi'=>'Keperawatan', 'smt'=>'VI',   'angkatan'=>2021, 'ipk'=>3.75, 'status'=>'Aktif',  'email'=>'anisa.n@stikesmni.ac.id',    'color'=>'#d0f5f2', 'tc'=>'#0d6e6e'],
        ['no'=>2, 'inisial'=>'BR', 'nama'=>'Budi Raharjo',     'nim'=>'2022.02.018', 'prodi'=>'Kebidanan',   'smt'=>'IV',   'angkatan'=>2022, 'ipk'=>3.60, 'status'=>'Aktif',  'email'=>'budi.r@stikesmni.ac.id',     'color'=>'#fdefd5', 'tc'=>'#c9923a'],
        ['no'=>3, 'inisial'=>'CS', 'nama'=>'Citra Sari',       'nim'=>'2023.03.007', 'prodi'=>'Farmasi',     'smt'=>'II',   'angkatan'=>2023, 'ipk'=>3.45, 'status'=>'Aktif',  'email'=>'citra.s@stikesmni.ac.id',    'color'=>'#e8f4fd', 'tc'=>'#4a90d9'],
        ['no'=>4, 'inisial'=>'DP', 'nama'=>'Dian Pratiwi',     'nim'=>'2021.01.061', 'prodi'=>'Keperawatan', 'smt'=>'VI',   'angkatan'=>2021, 'ipk'=>null, 'status'=>'Cuti',   'email'=>'dian.p@stikesmni.ac.id',     'color'=>'#fff0e0', 'tc'=>'#c9923a'],
        ['no'=>5, 'inisial'=>'EW', 'nama'=>'Eko Wahyudi',      'nim'=>'2020.01.033', 'prodi'=>'Analis',      'smt'=>'VIII', 'angkatan'=>2020, 'ipk'=>3.82, 'status'=>'Lulus',  'email'=>'eko.w@stikesmni.ac.id',      'color'=>'#f0ffe8', 'tc'=>'#1da870'],
        ['no'=>6, 'inisial'=>'FL', 'nama'=>'Fitriani Lubis',   'nim'=>'2022.01.099', 'prodi'=>'Keperawatan', 'smt'=>'IV',   'angkatan'=>2022, 'ipk'=>3.52, 'status'=>'Aktif',  'email'=>'fitriani.l@stikesmni.ac.id', 'color'=>'#d0f5f2', 'tc'=>'#0d6e6e'],
        ['no'=>7, 'inisial'=>'GH', 'nama'=>'Gilang Hakim',     'nim'=>'2023.05.012', 'prodi'=>'Fisioterapi', 'smt'=>'II',   'angkatan'=>2023, 'ipk'=>3.38, 'status'=>'Aktif',  'email'=>'gilang.h@stikesmni.ac.id',   'color'=>'#ede8ff', 'tc'=>'#8b6fcb'],
        ['no'=>8, 'inisial'=>'HR', 'nama'=>'Hana Rasyida',     'nim'=>'2021.03.025', 'prodi'=>'Farmasi',     'smt'=>'VI',   'angkatan'=>2021, 'ipk'=>3.91, 'status'=>'Aktif',  'email'=>'hana.r@stikesmni.ac.id',     'color'=>'#e8f4fd', 'tc'=>'#4a90d9'],
        ['no'=>9, 'inisial'=>'IK', 'nama'=>'Irfan Kusuma',     'nim'=>'2022.04.008', 'prodi'=>'Analis',      'smt'=>'IV',   'angkatan'=>2022, 'ipk'=>3.20, 'status'=>'DO',     'email'=>'irfan.k@stikesmni.ac.id',    'color'=>'#ffe8e8', 'tc'=>'#e05555'],
        ['no'=>10,'inisial'=>'JN', 'nama'=>'Julia Nanda',      'nim'=>'2023.01.044', 'prodi'=>'Keperawatan', 'smt'=>'II',   'angkatan'=>2023, 'ipk'=>3.55, 'status'=>'Aktif',  'email'=>'julia.n@stikesmni.ac.id',    'color'=>'#d0f5f2', 'tc'=>'#0d6e6e'],
    ];
    if ($filter !== 'semua') {
        $data = array_filter($data, fn($m) => strtolower($m['prodi']) === strtolower($filter));
    }
    return $data;
}

function get_dosen() {
    return [
        ['inisial'=>'SH','nama'=>'dr. Siti Hajar, M.Kes',      'prodi'=>'Keperawatan','jabatan'=>'Lektor Kepala','mk'=>4,'rating'=>4.9,'status'=>'Aktif', 'color'=>'#d0f5f2','tc'=>'#0d6e6e'],
        ['inisial'=>'AR','nama'=>'Ahmad Riza, S.Kep., M.Kep',   'prodi'=>'Keperawatan','jabatan'=>'Lektor',       'mk'=>3,'rating'=>4.8,'status'=>'Aktif', 'color'=>'#fdefd5','tc'=>'#c9923a'],
        ['inisial'=>'RM','nama'=>'Rahmi Maulida, Ph.D',         'prodi'=>'Farmasi',    'jabatan'=>'Guru Besar',   'mk'=>2,'rating'=>4.8,'status'=>'Aktif', 'color'=>'#e8f4fd','tc'=>'#4a90d9'],
        ['inisial'=>'BN','nama'=>'Baharuddin, M.Farm',          'prodi'=>'Farmasi',    'jabatan'=>'Lektor',       'mk'=>5,'rating'=>4.7,'status'=>'Aktif', 'color'=>'#f0ffe8','tc'=>'#1da870'],
        ['inisial'=>'ZA','nama'=>'Zulfikar Amri, M.Fis',        'prodi'=>'Fisioterapi','jabatan'=>'Asisten Ahli', 'mk'=>4,'rating'=>4.6,'status'=>'Aktif', 'color'=>'#ede8ff','tc'=>'#8b6fcb'],
        ['inisial'=>'NI','nama'=>'Nurul Izzati, Bd., M.Keb',    'prodi'=>'Kebidanan',  'jabatan'=>'Lektor',       'mk'=>3,'rating'=>4.5,'status'=>'Cuti',  'color'=>'#fff0e0','tc'=>'#c9923a'],
        ['inisial'=>'MH','nama'=>'Muhammad Hasan, M.AK',        'prodi'=>'Analis',     'jabatan'=>'Asisten Ahli', 'mk'=>3,'rating'=>4.4,'status'=>'Aktif', 'color'=>'#d0f5f2','tc'=>'#0d6e6e'],
        ['inisial'=>'FD','nama'=>'Farida Dewi, M.Kep',          'prodi'=>'Keperawatan','jabatan'=>'Lektor',       'mk'=>4,'rating'=>4.7,'status'=>'Aktif', 'color'=>'#fdefd5','tc'=>'#c9923a'],
        ['inisial'=>'YP','nama'=>'Yusra Putri, M.Farm',         'prodi'=>'Farmasi',    'jabatan'=>'Asisten Ahli', 'mk'=>3,'rating'=>4.3,'status'=>'Aktif', 'color'=>'#e8f4fd','tc'=>'#4a90d9'],
    ];
}

function get_praktik() {
    return [
        ['nama'=>'RSUD Zainal Abidin',    'kota'=>'Banda Aceh',  'tipe'=>'RS Tipe A', 'tipe_badge'=>'badge-red',    'mhs'=>48, 'periode'=>'Jan–Jun 2025','status'=>'Aktif',    'supervisor'=>'dr. Chairul'],
        ['nama'=>'RS Pertamedika',         'kota'=>'Banda Aceh',  'tipe'=>'RS Swasta', 'tipe_badge'=>'badge-blue',   'mhs'=>32, 'periode'=>'Jan–Jun 2025','status'=>'Aktif',    'supervisor'=>'dr. Rina'],
        ['nama'=>'Puskesmas Garot',        'kota'=>'Sigli',       'tipe'=>'Puskesmas', 'tipe_badge'=>'badge-teal',   'mhs'=>20, 'periode'=>'Mar–Jun 2025','status'=>'Menunggu', 'supervisor'=>'dr. Safri'],
        ['nama'=>'RSUD Tgk. Chik Ditiro', 'kota'=>'Sigli',       'tipe'=>'RS Tipe B', 'tipe_badge'=>'badge-red',    'mhs'=>15, 'periode'=>'Sep–Des 2024','status'=>'Selesai',  'supervisor'=>'dr. Amir'],
        ['nama'=>'RSU Bunda Thamrin',      'kota'=>'Medan',       'tipe'=>'RS Swasta', 'tipe_badge'=>'badge-blue',   'mhs'=>27, 'periode'=>'Jan–Jun 2025','status'=>'Aktif',    'supervisor'=>'dr. Lili'],
        ['nama'=>'Klinik Pratama Sehat',   'kota'=>'Banda Aceh',  'tipe'=>'Klinik',    'tipe_badge'=>'badge-purple', 'mhs'=>14, 'periode'=>'Feb–Jun 2025','status'=>'Aktif',    'supervisor'=>'dr. Fauzi'],
        ['nama'=>'Puskesmas Batuphat',     'kota'=>'Lhokseumawe', 'tipe'=>'Puskesmas', 'tipe_badge'=>'badge-teal',   'mhs'=>18, 'periode'=>'Jan–Jun 2025','status'=>'Aktif',    'supervisor'=>'dr. Maisara'],
        ['nama'=>'RSIA Bunda',             'kota'=>'Banda Aceh',  'tipe'=>'RS Ibu-Anak','tipe_badge'=>'badge-purple','mhs'=>22, 'periode'=>'Jan–Jun 2025','status'=>'Aktif',    'supervisor'=>'dr. Nurlia'],
    ];
}

function get_transaksi() {
    return [
        ['tanggal'=>'28 Jun 2025','deskripsi'=>'SPP Semester Genap 2025','sub'=>'Anisa Nurhayati · 2021.01.042','kategori'=>'SPP',    'cat_badge'=>'badge-teal',  'metode'=>'Transfer Bank','nominal'=>'+Rp 3.500.000','tipe'=>'Masuk', 'tipe_badge'=>'badge-green'],
        ['tanggal'=>'27 Jun 2025','deskripsi'=>'Pembelian Alat Lab',      'sub'=>'Supplier Medis Nusantara',     'kategori'=>'Sarana', 'cat_badge'=>'badge-red',   'metode'=>'Transfer Bank','nominal'=>'-Rp 8.750.000','tipe'=>'Keluar','tipe_badge'=>'badge-red'],
        ['tanggal'=>'26 Jun 2025','deskripsi'=>'Gaji Dosen & Staff',      'sub'=>'Bulan Juni 2025',              'kategori'=>'SDM',    'cat_badge'=>'badge-gold',  'metode'=>'Transfer Bank','nominal'=>'-Rp 42.000.000','tipe'=>'Keluar','tipe_badge'=>'badge-red'],
        ['tanggal'=>'25 Jun 2025','deskripsi'=>'Beasiswa Prestasi',       'sub'=>'Eko Wahyudi · Beasiswa Penuh', 'kategori'=>'Beasiswa','cat_badge'=>'badge-purple','metode'=>'Transfer Bank','nominal'=>'-Rp 3.500.000','tipe'=>'Keluar','tipe_badge'=>'badge-red'],
        ['tanggal'=>'24 Jun 2025','deskripsi'=>'SPP & Uang Gedung',       'sub'=>'Fitriani Lubis · 2022.01.099', 'kategori'=>'SPP',    'cat_badge'=>'badge-teal',  'metode'=>'QRIS',         'nominal'=>'+Rp 4.200.000','tipe'=>'Masuk', 'tipe_badge'=>'badge-green'],
        ['tanggal'=>'23 Jun 2025','deskripsi'=>'Biaya Akreditasi LAM',    'sub'=>'Prodi Keperawatan',            'kategori'=>'Admin',  'cat_badge'=>'badge-blue',  'metode'=>'Transfer Bank','nominal'=>'-Rp 12.000.000','tipe'=>'Keluar','tipe_badge'=>'badge-red'],
        ['tanggal'=>'22 Jun 2025','deskripsi'=>'Dana Hibah Penelitian',   'sub'=>'DIKTI 2025',                   'kategori'=>'Hibah',  'cat_badge'=>'badge-green', 'metode'=>'Transfer Bank','nominal'=>'+Rp 25.000.000','tipe'=>'Masuk', 'tipe_badge'=>'badge-green'],
    ];
}
