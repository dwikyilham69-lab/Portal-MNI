<?php
function status_badge($status) {
    $map = [
        'Aktif'    => 'badge-green',
        'Cuti'     => 'badge-gold',
        'Lulus'    => 'badge-gray',
        'DO'       => 'badge-red',
        'Menunggu' => 'badge-gold',
        'Selesai'  => 'badge-gray',
    ];
    $cls = $map[$status] ?? 'badge-gray';
    $dot = in_array($status, ['Aktif']) ? '● ' : '';
    return "<span class=\"badge {$cls}\">{$dot}{$status}</span>";
}

function prodi_badge($prodi) {
    $map = [
        'Keperawatan' => 'badge-teal',
        'Kebidanan'   => 'badge-purple',
        'Farmasi'     => 'badge-blue',
        'Analis'      => 'badge-gold',
        'Fisioterapi' => 'badge-green',
    ];
    $cls = $map[$prodi] ?? 'badge-gray';
    return "<span class=\"badge {$cls}\">{$prodi}</span>";
}

function jabatan_badge($jabatan) {
    $map = [
        'Guru Besar'   => 'badge-gold',
        'Lektor Kepala'=> 'badge-teal',
        'Lektor'       => 'badge-teal',
        'Asisten Ahli' => 'badge-blue',
    ];
    $cls = $map[$jabatan] ?? 'badge-gray';
    return "<span class=\"badge {$cls}\">{$jabatan}</span>";
}

function ipk_color($ipk) {
    if ($ipk === null) return 'var(--text-light)';
    if ($ipk >= 3.7) return 'var(--green-soft)';
    if ($ipk >= 3.3) return 'var(--teal-mid)';
    return 'var(--gold)';
}

function current_page() {
    return isset($_GET['page']) ? $_GET['page'] : 'dashboard';
}

function nav_active($p) {
    return current_page() === $p ? 'active' : '';
}

function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}
