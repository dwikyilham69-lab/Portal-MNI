<?php
function handle_login() {
    $users = [
        'admin'      => ['password' => 'stikesmni2025', 'role' => 'Admin',      'name' => 'Administrator'],
        'dosen1'     => ['password' => 'dosen123',      'role' => 'Dosen',      'name' => 'dr. Siti Hajar, M.Kes'],
        'mahasiswa1' => ['password' => 'mhs123',        'role' => 'Mahasiswa',  'name' => 'Anisa Nurhayati'],
        'keuangan1'  => ['password' => 'keu123',        'role' => 'Keuangan',   'name' => 'Staff Keuangan'],
    ];

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $error = '';

    if (empty($username) || empty($password)) {
        $error = 'Username dan kata sandi wajib diisi.';
    } elseif (!isset($users[$username]) || $users[$username]['password'] !== $password) {
        $error = 'Username atau kata sandi tidak valid.';
    } else {
        $_SESSION['user'] = [
            'username' => $username,
            'name'     => $users[$username]['name'],
            'role'     => $users[$username]['role'],
        ];
        header('Location: index.php?page=dashboard');
        exit;
    }

    // Return to login with error
    $_SESSION['login_error'] = $error;
    header('Location: index.php?page=login');
    exit;
}
