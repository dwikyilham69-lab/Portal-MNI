<?php
require_once 'includes/helpers.php';
require_once 'includes/data.php';
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
$user = $_SESSION['user'];
$page_titles = [
    'dashboard'  => 'Dashboard',
    'mahasiswa'  => 'Data Mahasiswa',
    'dosen'      => 'Data Dosen',
    'praktik'    => 'Praktik Klinik',
    'keuangan'   => 'Laporan Keuangan',
    'jadwal'     => 'Jadwal Kuliah',
    'laporan'    => 'Laporan',
    'pengaturan' => 'Pengaturan',
];
$title = $page_titles[$page] ?? 'Dashboard';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($title) ?> — STIKES MNI</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
<div class="app-layout">

  <!-- ── SIDEBAR ── -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="sidebar-logo-icon">⚕️</div>
      <div class="sidebar-logo-text">
        <div class="name">STIKES MNI</div>
        <div class="sub">Sistem Informasi Akademik</div>
      </div>
    </div>

    <div class="sidebar-section-label">Menu Utama</div>
    <a href="index.php?page=dashboard"  class="nav-item <?= nav_active('dashboard') ?>"><span class="icon">📊</span> Dashboard</a>
    <a href="index.php?page=mahasiswa"  class="nav-item <?= nav_active('mahasiswa') ?>"><span class="icon">🎓</span> Mahasiswa <span class="nav-badge">1.2k</span></a>
    <a href="index.php?page=dosen"      class="nav-item <?= nav_active('dosen') ?>"><span class="icon">👨‍🏫</span> Dosen</a>
    <a href="index.php?page=praktik"    class="nav-item <?= nav_active('praktik') ?>"><span class="icon">🏥</span> Praktik Klinik</a>
    <a href="index.php?page=keuangan"   class="nav-item <?= nav_active('keuangan') ?>"><span class="icon">💰</span> Keuangan</a>

    <div class="sidebar-section-label">Administrasi</div>
    <a href="index.php?page=jadwal"     class="nav-item <?= nav_active('jadwal') ?>"><span class="icon">📅</span> Jadwal</a>
    <a href="index.php?page=laporan"    class="nav-item <?= nav_active('laporan') ?>"><span class="icon">📋</span> Laporan</a>
    <a href="index.php?page=pengaturan" class="nav-item <?= nav_active('pengaturan') ?>"><span class="icon">⚙️</span> Pengaturan</a>

    <div class="sidebar-bottom">
      <div class="user-card">
        <div class="user-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></div>
        <div>
          <div class="user-name"><?= h($user['name']) ?></div>
          <div class="user-role"><?= h($user['role']) ?></div>
        </div>
        <a href="index.php?page=logout" class="btn-logout">Keluar</a>
      </div>
    </div>
  </aside>

  <!-- ── MAIN ── -->
  <main class="main-content">
    <div class="topbar">
      <div style="flex:1">
        <div class="topbar-title"><?= h($title) ?></div>
      </div>
      <form class="topbar-search" method="get" action="index.php">
        <input type="hidden" name="page" value="<?= h($page) ?>">
        <span>🔍</span>
        <input type="text" name="q" placeholder="Cari mahasiswa, dosen..." value="<?= h($_GET['q'] ?? '') ?>">
      </form>
      <div class="topbar-actions">
        <div class="topbar-btn">🔔<div class="notif-dot"></div></div>
        <span class="semester-badge">Semester Genap 2024/2025</span>
      </div>
    </div>

    <div class="content-area">
      <?php require_once "pages/{$page}.php"; ?>
    </div>
  </main>
</div>
<script src="assets/js/main.js"></script>
</body>
</html>
