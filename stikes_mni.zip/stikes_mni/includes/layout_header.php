<?php
// includes/layout_header.php
// Dipanggil di awal setiap halaman dashboard dengan parameter:
// $pageTitle  = judul halaman
// $activePage = nama halaman aktif (dashboard, mahasiswa, dosen, praktik, keuangan, dsb)

$user = getSessionUser();

$navItems = [
    ['key'=>'dashboard', 'icon'=>'📊', 'label'=>'Dashboard',      'badge'=>null],
    ['key'=>'mahasiswa', 'icon'=>'🎓', 'label'=>'Mahasiswa',       'badge'=>'1.2k'],
    ['key'=>'dosen',     'icon'=>'👨‍🏫', 'label'=>'Dosen',           'badge'=>null],
    ['key'=>'praktik',   'icon'=>'🏥', 'label'=>'Praktik Klinik',  'badge'=>null],
    ['key'=>'keuangan',  'icon'=>'💰', 'label'=>'Keuangan',         'badge'=>null],
];
$adminItems = [
    ['key'=>'kurikulum', 'icon'=>'📚', 'label'=>'Kurikulum',  'badge'=>null],
    ['key'=>'jadwal',    'icon'=>'📅', 'label'=>'Jadwal',     'badge'=>null],
    ['key'=>'laporan',   'icon'=>'📋', 'label'=>'Laporan',    'badge'=>null],
    ['key'=>'pengaturan','icon'=>'⚙️', 'label'=>'Pengaturan', 'badge'=>null],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'Dashboard') ?> — STIKES MNI</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
<div class="app-layout">

  <!-- ─── SIDEBAR ─── -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="sidebar-logo-icon">⚕️</div>
      <div class="sidebar-logo-text">
        <div class="name">STIKES MNI</div>
        <div class="sub">Sistem Informasi Akademik</div>
      </div>
    </div>

    <div class="sidebar-section-label">Menu Utama</div>
    <?php foreach ($navItems as $item): ?>
      <a href="<?= $item['key'] ?>.php" class="nav-item <?= ($activePage ?? '') === $item['key'] ? 'active' : '' ?>">
        <span class="icon"><?= $item['icon'] ?></span>
        <?= e($item['label']) ?>
        <?php if ($item['badge']): ?>
          <span class="nav-badge"><?= $item['badge'] ?></span>
        <?php endif; ?>
      </a>
    <?php endforeach; ?>

    <?php if (hasRole('admin')): ?>
    <div class="sidebar-section-label">Administrasi</div>
    <?php foreach ($adminItems as $item): ?>
      <a href="<?= $item['key'] ?>.php" class="nav-item <?= ($activePage ?? '') === $item['key'] ? 'active' : '' ?>">
        <span class="icon"><?= $item['icon'] ?></span>
        <?= e($item['label']) ?>
      </a>
    <?php endforeach; ?>
    <?php endif; ?>

    <div class="sidebar-bottom">
      <div class="user-card">
        <?php $ac = avatarColor($user['nama']); ?>
        <div class="user-avatar" style="background:<?= $ac['bg'] ?>;color:<?= $ac['fg'] ?>">
          <?= initials($user['nama']) ?>
        </div>
        <div>
          <div class="user-name"><?= e($user['nama']) ?></div>
          <div class="user-role"><?= ucfirst($user['role']) ?></div>
        </div>
        <a href="logout.php" class="btn-logout">Keluar</a>
      </div>
    </div>
  </aside>

  <!-- ─── MAIN ─── -->
  <main class="main-content">
    <div class="topbar">
      <div style="flex:1">
        <div class="topbar-title"><?= e($pageTitle ?? 'Dashboard') ?></div>
      </div>
      <form class="topbar-search" method="get" action="mahasiswa.php">
        <span>🔍</span>
        <input type="text" name="q" placeholder="Cari mahasiswa, dosen..." value="<?= e($_GET['q'] ?? '') ?>">
      </form>
      <div class="topbar-actions">
        <div class="topbar-btn">🔔<div class="notif-dot"></div></div>
        <span class="semester-badge">Semester Genap 2024/2025</span>
      </div>
    </div>

    <div class="content-area">
