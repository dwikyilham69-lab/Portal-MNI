<?php
$error = '';
if (isset($_SESSION['login_error'])) {
    $error = $_SESSION['login_error'];
    unset($_SESSION['login_error']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — STIKES Medika Nurul Islam</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
</head>
<body>
<div id="login-page">
  <div class="login-deco">
    <div class="login-deco-art">
      <div class="deco-circle"></div>
      <div class="deco-circle"></div>
      <div class="deco-circle"></div>
      <div class="deco-icon">🏥</div>
    </div>
    <div class="login-deco-text">
      <h1>STIKES Medika<br>Nurul Islam</h1>
      <p>Sistem Informasi Akademik terintegrasi untuk mendukung pelayanan pendidikan kesehatan terbaik</p>
    </div>
    <div class="login-stats">
      <div class="login-stat"><div class="num">1.248</div><div class="lbl">Mahasiswa</div></div>
      <div class="login-stat"><div class="num">87</div><div class="lbl">Dosen</div></div>
      <div class="login-stat"><div class="num">34</div><div class="lbl">Lokasi Praktik</div></div>
    </div>
  </div>

  <div class="login-form-panel">
    <div class="login-logo">
      <div class="login-logo-icon">⚕️</div>
      <div class="login-logo-text">
        <div class="name">STIKES MNI</div>
        <div class="sub">Sistem Informasi Akademik</div>
      </div>
    </div>
    <h2>Selamat Datang</h2>
    <p class="subtitle">Masuk untuk mengakses portal akademik Anda</p>

    <?php if ($error): ?>
    <div style="border:1px solid rgba(224,85,85,0.3);background:rgba(224,85,85,0.06);border-radius:8px;padding:10px 14px;margin-bottom:18px;display:flex;gap:10px;align-items:center;">
      <span>⚠️</span><span style="font-size:13px;color:#c04040"><?= htmlspecialchars($error) ?></span>
    </div>
    <?php endif; ?>

    <div style="margin-bottom:20px;">
      <div style="font-size:12px;font-weight:500;color:var(--text-mid);margin-bottom:8px;">Akun Demo:</div>
      <div class="login-role-btns">
        <button type="button" class="role-btn active" onclick="fillDemo('admin','stikesmni2025',this)">🔐 Admin</button>
        <button type="button" class="role-btn" onclick="fillDemo('dosen1','dosen123',this)">👨‍🏫 Dosen</button>
        <button type="button" class="role-btn" onclick="fillDemo('mahasiswa1','mhs123',this)">🎓 Mahasiswa</button>
        <button type="button" class="role-btn" onclick="fillDemo('keuangan1','keu123',this)">💼 Keuangan</button>
      </div>
    </div>

    <form method="POST" action="index.php?page=login">
      <div class="form-group">
        <label for="username">NIP / NIM / Username</label>
        <input type="text" id="username" name="username" placeholder="Masukkan username Anda"
               value="<?= htmlspecialchars($_POST['username'] ?? 'admin') ?>" required>
      </div>
      <div class="form-group">
        <label for="password">Kata Sandi</label>
        <input type="password" id="password" name="password" placeholder="••••••••" required>
      </div>
      <div class="login-options">
        <label class="remember"><input type="checkbox" name="remember" checked> Ingat saya</label>
        <a href="#" class="forgot">Lupa kata sandi?</a>
      </div>
      <button type="submit" class="btn-login">🔓 Masuk ke Sistem</button>
    </form>
    <div style="margin-top:20px;background:var(--mint);border-radius:8px;padding:12px 14px;font-size:12px;color:var(--text-mid);text-align:center;border:1px solid var(--border);">
      Pilih role di atas untuk mengisi otomatis, lalu klik <strong style="color:var(--teal-mid)">Masuk ke Sistem</strong>
    </div>
  </div>
</div>
<script src="assets/js/main.js"></script>
</body>
</html>
