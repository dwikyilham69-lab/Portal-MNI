<?php
$jadwal = [
  'Senin'   => [
    ['jam'=>'07:30–09:10','mk'=>'Keperawatan Dasar','ruang'=>'Ruang A1',  'color'=>'var(--teal-bright)'],
    ['jam'=>'10:00–11:40','mk'=>'Anatomi Fisiologi', 'ruang'=>'Lab Bio',   'color'=>'var(--gold)'],
    ['jam'=>'13:00–14:40','mk'=>'KMB I',             'ruang'=>'Ruang A2',  'color'=>'var(--blue-soft)'],
  ],
  'Selasa'  => [
    ['jam'=>'08:00–09:40','mk'=>'Komunikasi Kep.',   'ruang'=>'Ruang B2',  'color'=>'var(--blue-soft)'],
    ['jam'=>'13:00–14:40','mk'=>'Gizi Klinik',       'ruang'=>'Ruang C1',  'color'=>'var(--gold)'],
  ],
  'Rabu'    => [
    ['jam'=>'07:30–09:10','mk'=>'Praktik Klinik',    'ruang'=>'RSUD ZA',   'color'=>'var(--green-soft)'],
    ['jam'=>'13:00–14:40','mk'=>'Etika Keperawatan', 'ruang'=>'Ruang A3',  'color(--teal-bright)'],
  ],
  'Kamis'   => [
    ['jam'=>'09:00–10:40','mk'=>'Farmakologi',       'ruang'=>'Lab Farmasi','color'=>'var(--purple-soft)'],
    ['jam'=>'13:00–14:40','mk'=>'Biokimia',          'ruang'=>'Lab Bio',    'color'=>'var(--teal-bright)'],
  ],
  'Jumat'   => [
    ['jam'=>'07:30–09:10','mk'=>'Keperawatan Jiwa',  'ruang'=>'Ruang C1',  'color'=>'var(--gold)'],
  ],
];
?>
<div class="page-header">
  <div class="page-header-left"><h2>📅 Jadwal Kuliah</h2><p>Jadwal perkuliahan semester berjalan</p></div>
  <div style="display:flex;gap:8px">
    <button class="btn-secondary" onclick="unduhJadwalTeks()">⬇️ Unduh Jadwal</button>
    <button class="btn-primary" onclick="alert('Tambah jadwal')">➕ Tambah Jadwal</button>
  </div>
</div>

<div class="card" style="margin-bottom:20px">
  <div class="card-header">
    <div class="card-title"><span>📅</span> Jadwal Mingguan — Prodi Keperawatan</div>
    <div class="filter-bar" style="margin:0">
      <button class="filter-btn active">Keperawatan</button>
      <button class="filter-btn" onclick="toggleFilter(this)">Kebidanan</button>
      <button class="filter-btn" onclick="toggleFilter(this)">Farmasi</button>
    </div>
  </div>
  <div class="card-body">
    <div class="schedule-grid">
    <?php foreach ($jadwal as $hari => $slots): ?>
      <div class="schedule-day">
        <div class="schedule-day-label"><?= $hari ?></div>
        <?php foreach ($slots as $s): ?>
        <div class="schedule-slot" style="border-left-color:<?= $s['color'] ?>">
          <div class="slot-time"><?= $s['jam'] ?></div>
          <div class="slot-course"><?= isset($h) ? $h($s['mk']) : htmlspecialchars($s['mk']) ?></div>
          <div class="slot-room">📍 <?= isset($h) ? $h($s['ruang']) : htmlspecialchars($s['ruang']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="two-col-equal">
  <div class="card">
    <div class="card-header"><div class="card-title"><span>📚</span> Daftar Mata Kuliah Aktif</div></div>
    <div class="card-body">
      <table class="data-table">
        <thead><tr><th>Kode MK</th><th>Mata Kuliah</th><th>SKS</th><th>Dosen</th></tr></thead>
        <tbody>
          <tr><td style="font-family:'DM Mono',monospace;font-size:12px">KEP.301</td><td>Keperawatan Dasar</td><td>3</td><td>dr. Siti Hajar</td></tr>
          <tr><td style="font-family:'DM Mono',monospace;font-size:12px">BIO.201</td><td>Anatomi Fisiologi</td><td>2</td><td>Ahmad Riza, M.Kep</td></tr>
          <tr><td style="font-family:'DM Mono',monospace;font-size:12px">KEP.302</td><td>KMB I</td><td>4</td><td>dr. Siti Hajar</td></tr>
          <tr><td style="font-family:'DM Mono',monospace;font-size:12px">FAR.201</td><td>Farmakologi</td><td>3</td><td>Baharuddin, M.Farm</td></tr>
          <tr><td style="font-family:'DM Mono',monospace;font-size:12px">KEP.401</td><td>Keperawatan Jiwa</td><td>3</td><td>Farida Dewi, M.Kep</td></tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title"><span>🏫</span> Ketersediaan Ruangan</div></div>
    <div class="card-body">
      <?php
      $ruangan = [
          ['nama'=>'Ruang A1','kapasitas'=>40,'status'=>'Terpakai','pct'=>100],
          ['nama'=>'Ruang A2','kapasitas'=>40,'status'=>'Terpakai','pct'=>100],
          ['nama'=>'Ruang B2','kapasitas'=>35,'status'=>'Terpakai','pct'=>100],
          ['nama'=>'Ruang C1','kapasitas'=>30,'status'=>'Tersedia','pct'=>0],
          ['nama'=>'Lab Bio',  'kapasitas'=>25,'status'=>'Terpakai','pct'=>100],
          ['nama'=>'Lab Farmasi','kapasitas'=>20,'status'=>'Tersedia','pct'=>0],
      ];
      ?>
      <div style="display:flex;flex-direction:column;gap:8px">
      <?php foreach ($ruangan as $r): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:8px 10px;border-radius:8px;background:var(--cream)">
          <div style="font-size:13px;font-weight:500;color:var(--text-dark);flex:1"><?= isset($h) ? $h($r['nama']) : htmlspecialchars($r['nama']) ?></div>
          <div style="font-size:11px;color:var(--text-light)">Kap. <?= $r['kapasitas'] ?></div>
          <span class="badge <?= $r['status'] === 'Tersedia' ? 'badge-green' : 'badge-red' ?>"><?= $r['status'] ?></span>
        </div>
      <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<script>
function unduhJadwalTeks() {
    const hariBlok = document.querySelectorAll('.schedule-day');
    if (hariBlok.length === 0) {
        alert('Data jadwal tidak ditemukan di halaman ini.');
        return;
    }

    let isiTeks = "=========================================\n";
    isiTeks    += "    JADWAL KULIAH MINGGUAN STIKES MNI    \n";
    isiTeks    += "=========================================\n\n";

    hariBlok.forEach(blok => {
        const namaHari = blok.querySelector('.schedule-day-label').innerText.trim();
        isiTeks += "📌 HARI: " + namaHari + "\n";
        isiTeks += "-----------------------------------------\n";

        const slots = blok.querySelectorAll('.schedule-slot');
        if (slots.length === 0) {
            isiTeks += "  (Tidak ada jadwal perkuliahan)\n";
        } else {
            slots.forEach(slot => {
                const waktu = slot.querySelector('.slot-time').innerText.trim();
                const matkul = slot.querySelector('.slot-course').innerText.trim();
                const ruangan = slot.querySelector('.slot-room').innerText.trim();
                
                isiTeks += `⏱️  ${waktu}\n`;
                isiTeks += `📖  Mata Kuliah : ${matkul}\n`;
                isiTeks += `   ${ruangan}\n`;
                isiTeks += " . . . . . . . . . . . . . . . . . . . .\n";
            });
        }
        isiTeks += "\n";
    });

    isiTeks += "Dibuat otomatis oleh Sistem Akademik STIKES MNI.\n";

    // Membuat file sementara di browser dan mendownloadnya
    const blob = new Blob([isiTeks], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.download = "jadwal_kuliah_stikes.txt";
    link.href = window.URL.createObjectURL(blob);
    link.style.display = 'none';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
</script>