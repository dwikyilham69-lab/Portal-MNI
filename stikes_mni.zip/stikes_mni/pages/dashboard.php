<?php
$stats = get_stats();
$mahasiswa = array_slice(get_mahasiswa(), 0, 6);
$praktik = get_praktik();
?>
<div class="page-header">
  <div class="page-header-left">
    <h2>👋 Selamat datang kembali, <?= h(explode(' ', $_SESSION['user']['name'])[0]) ?>!</h2>
    <p>Semester Genap 2024/2025 — <?= date('l, d F Y') ?></p>
  </div>
  <span class="semester-badge" style="font-size:12px;padding:8px 16px">Semester Genap 2025/2026</span>
</div>

<!-- Stat Cards -->
<div class="stats-grid">
  <div class="stat-card teal">
    <div class="stat-card-header"><div class="stat-icon teal">🎓</div><span class="stat-trend up">↑ +42</span></div>
    <div class="stat-value"><?= number_format($stats['total_mahasiswa']) ?></div>
    <div class="stat-label">Total Mahasiswa</div>
    <div class="stat-sub">👥 Aktif semester ini</div>
  </div>
  <div class="stat-card gold">
    <div class="stat-card-header"><div class="stat-icon gold">👨‍🏫</div><span class="stat-trend up">↑ 72 aktif</span></div>
    <div class="stat-value"><?= $stats['total_dosen'] ?></div>
    <div class="stat-label">Total Dosen</div>
    <div class="stat-sub">📖 <?= $stats['dosen_aktif'] ?> aktif mengajar</div>
  </div>
  <div class="stat-card green">
    <div class="stat-card-header"><div class="stat-icon green">🏥</div><span class="stat-trend up">↑ +3 baru</span></div>
    <div class="stat-value"><?= $stats['total_praktik'] ?></div>
    <div class="stat-label">Lokasi Praktik</div>
    <div class="stat-sub">📍 Banda Aceh · Sigli · Medan</div>
  </div>
  <div class="stat-card blue">
    <div class="stat-card-header"><div class="stat-icon blue">💰</div><span class="stat-trend up">↑ +8%</span></div>
    <div class="stat-value">Rp <?= $stats['pendapatan_bulan'] ?></div>
    <div class="stat-label">Pendapatan Bulan Ini</div>
    <div class="stat-sub">📈 vs bulan lalu +8%</div>
  </div>
</div>

<div class="two-col">
  <!-- Mahasiswa Terbaru -->
  <div class="card">
    <div class="card-header">
      <div class="card-title"><span class="icon">🎓</span> Mahasiswa Aktif Terbaru</div>
      <a href="index.php?page=mahasiswa" class="card-action">Lihat semua →</a>
    </div>
    <div class="card-body">
      <table class="data-table">
        <thead><tr><th>Nama</th><th>NIM</th><th>Prodi</th><th>Smt</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($mahasiswa as $m): ?>
          <tr>
            <td><div class="avatar-cell">
              <div class="avatar-sm" style="background:<?= h($m['color']) ?>;color:<?= h($m['tc']) ?>"><?= h($m['inisial']) ?></div>
              <div class="name-cell"><?= h($m['nama']) ?></div>
            </div></td>
            <td style="font-family:'DM Mono',monospace;font-size:12px"><?= h($m['nim']) ?></td>
            <td><?= prodi_badge($m['prodi']) ?></td>
            <td><?= h($m['smt']) ?></td>
            <td><?= status_badge($m['status']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Praktik Klinik -->
  <div class="card">
    <div class="card-header">
      <div class="card-title"><span class="icon">🏥</span> Praktik Klinik</div>
      <a href="index.php?page=praktik" class="card-action">Detail →</a>
    </div>
    <div class="card-body">
      <div class="clinic-list">
        <?php foreach (array_slice($praktik, 0, 5) as $pk): ?>
        <div class="clinic-item">
          <div class="clinic-dot <?= strtolower(str_replace(' ','',h($pk['status']))) ?>"></div>
          <div class="clinic-info">
            <div class="clinic-name"><?= h($pk['nama']) ?></div>
            <div class="clinic-meta">📍 <?= h($pk['kota']) ?></div>
          </div>
          <div class="clinic-count"><?= $pk['mhs'] ?> mhs</div>
          <?= status_badge($pk['status']) ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<div class="two-col-equal">
  <!-- Grafik Keuangan -->
  <div class="card">
    <div class="card-header">
      <div class="card-title"><span class="icon">📈</span> Tren Keuangan 6 Bulan</div>
      <a href="index.php?page=keuangan" class="card-action">Laporan →</a>
    </div>
    <div class="card-body">
      <div class="bar-chart-wrap" id="fin-chart"></div>
      <div class="chart-labels">
        <?php foreach (['Jan','Feb','Mar','Apr','Mei','Jun'] as $m): ?>
        <div class="chart-label" style="flex:1;text-align:center"><?= $m ?></div>
        <?php endforeach; ?>
      </div>
      <div style="display:flex;gap:16px;margin-top:10px">
        <div style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text-light)"><div style="width:10px;height:10px;background:var(--teal-mid);border-radius:2px"></div>Pemasukan</div>
        <div style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text-light)"><div style="width:10px;height:10px;background:var(--gold);border-radius:2px"></div>Pengeluaran</div>
      </div>
    </div>
  </div>

  <!-- Distribusi Prodi -->
  <div class="card">
    <div class="card-header"><div class="card-title"><span class="icon">📊</span> Distribusi Mahasiswa per Prodi</div></div>
    <div class="card-body">
      <div class="donut-wrap">
        <svg class="donut-svg" width="120" height="120" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="45" fill="none" stroke="#e8f5f5" stroke-width="22"/>
          <circle cx="60" cy="60" r="45" fill="none" stroke="#0d6e6e" stroke-width="22" stroke-dasharray="127 155" stroke-dashoffset="35" stroke-linecap="round"/>
          <circle cx="60" cy="60" r="45" fill="none" stroke="#c9923a" stroke-width="22" stroke-dasharray="66 216" stroke-dashoffset="-92" stroke-linecap="round"/>
          <circle cx="60" cy="60" r="45" fill="none" stroke="#4a90d9" stroke-width="22" stroke-dasharray="50 232" stroke-dashoffset="-158" stroke-linecap="round"/>
          <circle cx="60" cy="60" r="45" fill="none" stroke="#8b6fcb" stroke-width="22" stroke-dasharray="39 243" stroke-dashoffset="-208" stroke-linecap="round"/>
          <text x="60" y="56" text-anchor="middle" font-size="16" font-weight="700" fill="#0d2e2e" font-family="Playfair Display">1.248</text>
          <text x="60" y="70" text-anchor="middle" font-size="9" fill="#7aa0a0" font-family="DM Sans">Mahasiswa</text>
        </svg>
        <div class="donut-legend">
          <div class="donut-item"><div class="donut-dot" style="background:#0d6e6e"></div><div class="donut-label">Keperawatan</div><div class="donut-val">512</div></div>
          <div class="donut-item"><div class="donut-dot" style="background:#c9923a"></div><div class="donut-label">Kebidanan</div><div class="donut-val">265</div></div>
          <div class="donut-item"><div class="donut-dot" style="background:#4a90d9"></div><div class="donut-label">Farmasi</div><div class="donut-val">198</div></div>
          <div class="donut-item"><div class="donut-dot" style="background:#8b6fcb"></div><div class="donut-label">Analis Kes.</div><div class="donut-val">157</div></div>
          <div class="donut-item"><div class="donut-dot" style="background:#2ecc8a"></div><div class="donut-label">Fisioterapi</div><div class="donut-val">116</div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="two-col-equal">
  <!-- Notifikasi -->
  <div class="card">
    <div class="card-header"><div class="card-title"><span class="icon">🔔</span> Notifikasi & Pengumuman</div></div>
    <div class="card-body">
      <div class="alert-list">
        <div class="alert-item warn"><div class="alert-icon">⚠️</div><div><div class="alert-title">Batas Pengisian KRS</div><div class="alert-desc">Mahasiswa semester III belum mengisi KRS. Tenggat: 15 Juli 2025</div></div></div>
        <div class="alert-item info"><div class="alert-icon">ℹ️</div><div><div class="alert-title">Jadwal UAS Sudah Dirilis</div><div class="alert-desc">Jadwal UAS Semester Genap tersedia di portal akademik</div></div></div>
        <div class="alert-item success"><div class="alert-icon">✅</div><div><div class="alert-title">Akreditasi LAM-PTKes</div><div class="alert-desc">Prodi Keperawatan berhasil mempertahankan Akreditasi B</div></div></div>
        <div class="alert-item warn"><div class="alert-icon">📋</div><div><div class="alert-title">Laporan Praktik Belum Dikumpulkan</div><div class="alert-desc">23 mahasiswa belum mengumpulkan laporan praktik RS Pertamedika</div></div></div>
      </div>
    </div>
  </div>
  <!-- Agenda -->
  <div class="card">
    <div class="card-header"><div class="card-title"><span class="icon">📅</span> Agenda Akademik</div></div>
    <div class="card-body">
      <div class="timeline">
        <div class="timeline-item"><div class="timeline-dot" style="background:var(--teal-bright)"></div><div class="timeline-title">Ujian Akhir Semester (UAS)</div><div class="timeline-meta">01 – 15 Juli 2025 · Semua Prodi</div></div>
        <div class="timeline-item"><div class="timeline-dot" style="background:var(--gold)"></div><div class="timeline-title">Pengumuman Kelulusan</div><div class="timeline-meta">25 Juli 2025 · Angkatan 2020</div></div>
        <div class="timeline-item"><div class="timeline-dot" style="background:var(--green-soft)"></div><div class="timeline-title">Wisuda Periode III</div><div class="timeline-meta">12 Agustus 2025 · Auditorium STIKES</div></div>
        <div class="timeline-item"><div class="timeline-dot" style="background:var(--blue-soft)"></div><div class="timeline-title">Penerimaan Mahasiswa Baru</div><div class="timeline-meta">Agustus 2025 · Semua Prodi</div></div>
        <div class="timeline-item"><div class="timeline-dot" style="background:var(--purple-soft)"></div><div class="timeline-title">Awal Semester Ganjil 2025/2026</div><div class="timeline-meta">01 September 2025</div></div>
      </div>
    </div>
  </div>
</div>
