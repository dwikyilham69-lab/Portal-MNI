<?php
// laporan.php
// Jika file ini membutuhkan auth atau database, silakan uncomment baris di bawah ini:
// require_once 'config/database.php';
// require_once 'includes/auth.php';
// require_once 'includes/helpers.php';
// requireLogin();
?>
<div class="page-header">
  <div class="page-header-left"><h2>📋 Laporan</h2><p>Generator laporan akademik dan administratif</p></div>
  <button class="btn-primary" onclick="alert('Membuka generator pembuatan laporan baru...')">➕ Buat Laporan</button>
</div>

<div class="three-col" style="margin-bottom:20px">
  <?php
  $jenis = [
    ['icon'=>'🎓','judul'=>'Laporan Akademik','desc'=>'Nilai, IPK, kelulusan mahasiswa','btn'=>'Buat'],
    ['icon'=>'💰','judul'=>'Laporan Keuangan','desc'=>'Pemasukan, pengeluaran, SPP','btn'=>'Buat'],
    ['icon'=>'🏥','judul'=>'Laporan Praktik','desc'=>'Penempatan & progress praktik klinik','btn'=>'Buat'],
    ['icon'=>'👨‍🏫','judul'=>'Laporan Dosen','desc'=>'Kehadiran dan kinerja mengajar','btn'=>'Buat'],
    ['icon'=>'📊','judul'=>'Laporan Akreditasi','desc'=>'Data untuk kebutuhan akreditasi','btn'=>'Buat'],
    ['icon'=>'🎯','judul'=>'Laporan Wisuda','desc'=>'Data calon wisudawan periode ini','btn'=>'Buat'],
  ];
  foreach ($jenis as $j): ?>
  <div class="card" style="cursor:pointer" onclick="alert('Membuka generator <?= isset($h) ? $h($j['judul']) : htmlspecialchars($j['judul']) ?>')">
    <div class="card-body" style="padding:24px;text-align:center">
      <div style="font-size:40px;margin-bottom:12px"><?= $j['icon'] ?></div>
      <div style="font-size:15px;font-weight:600;color:var(--text-dark);margin-bottom:6px"><?= isset($h) ? $h($j['judul']) : htmlspecialchars($j['judul']) ?></div>
      <div style="font-size:12px;color:var(--text-light);margin-bottom:16px"><?= isset($h) ? $h($j['desc']) : htmlspecialchars($j['desc']) ?></div>
      <button class="btn-primary" style="width:100%;justify-content:center">📄 <?= $j['btn'] ?></button>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-header"><div class="card-title"><span>📁</span> Riwayat Laporan Terakhir</div></div>
  <div class="card-body">
    <table class="data-table">
      <thead><tr><th>Nama Laporan</th><th>Tipe</th><th>Dibuat</th><th>Oleh</th><th>Aksi</th></tr></thead>
      <tbody>
        <tr>
          <td><strong>Laporan Akademik Semester Genap 2024/2025</strong></td>
          <td><span class="badge badge-teal">Akademik</span></td>
          <td>28 Jun 2025</td>
          <td>Admin</td>
          <td><button style="background:none;border:none;cursor:pointer" onclick="prosesUnduhLaporan('Laporan Akademik Semester Genap 2024_2025', 'Akademik')">⬇️ Unduh</button></td>
        </tr>
        <tr>
          <td><strong>Laporan Keuangan Mei 2025</strong></td>
          <td><span class="badge badge-gold">Keuangan</span></td>
          <td>01 Jun 2025</td>
          <td>Admin</td>
          <td><button style="background:none;border:none;cursor:pointer" onclick="prosesUnduhLaporan('Laporan Keuangan Mei 2025', 'Keuangan')">⬇️ Unduh</button></td>
        </tr>
        <tr>
          <td><strong>Laporan Praktik RS Pertamedika</strong></td>
          <td><span class="badge badge-red">Praktik</span></td>
          <td>20 Mei 2025</td>
          <td>Admin</td>
          <td><button style="background:none;border:none;cursor:pointer" onclick="prosesUnduhLaporan('Laporan Praktik RS Pertamedika', 'Praktik')">⬇️ Unduh</button></td>
        </tr>
        <tr>
          <td><strong>Laporan Wisuda Periode II 2025</strong></td>
          <td><span class="badge badge-blue">Wisuda</span></td>
          <td>10 Mei 2025</td>
          <td>Admin</td>
          <td><button style="background:none;border:none;cursor:pointer" onclick="prosesUnduhLaporan('Laporan Wisuda Periode II 2025', 'Wisuda')">⬇️ Unduh</button></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<script>
function prosesUnduhLaporan(namaLaporan, tipeLaporan) {
    let isiFile = "";
    
    // Membuat template isi teks laporan otomatis berdasarkan tipe yang diklik
    if (tipeLaporan === "Akademik") {
        isiFile = "JUDUL LAPORAN: " + namaLaporan + "\n" +
                  "Dibuat: 28 Juni 2025\n" +
                  "Oleh: Admin STIKES MNI\n" +
                  "==================================================\n" +
                  "NIM,Nama Mahasiswa,Program Studi,IPK,Status\n" +
                  "1022001,Ahmad Rifai,Keperawatan,3.65,Aktif\n" +
                  "1022002,Siti Aminah,Kebidanan,3.82,Aktif\n" +
                  "1022003,Budi Santoso,Farmasi,2.95,Aktif\n" +
                  "==================================================\n" +
                  "Ringkasan: Rata-rata IPK institusi Semester Genap adalah 3.47.";
    } else if (tipeLaporan === "Keuangan") {
        isiFile = "JUDUL LAPORAN: " + namaLaporan + "\n" +
                  "Dibuat: 01 Juni 2025\n" +
                  "Oleh: Admin STIKES MNI\n" +
                  "==================================================\n" +
                  "Kategori,Keterangan,Nominal (IDR)\n" +
                  "Pemasukan,Pembayaran SPP Mahasiswa,450000000\n" +
                  "Pemasukan,Dana Hibah Penelitian,25000000\n" +
                  "Pengeluaran,Gaji Dosen & Staff,180000000\n" +
                  "Pengeluaran,Operasional & Inventaris,4500000\n" +
                  "==================================================\n" +
                  "Total Saldo Bersih Bulan Mei: +290,500,000 IDR";
    } else if (tipeLaporan === "Praktik") {
        isiFile = "JUDUL LAPORAN: " + namaLaporan + "\n" +
                  "Dibuat: 20 Mei 2025\n" +
                  "Oleh: Admin STIKES MNI\n" +
                  "==================================================\n" +
                  "Nama Rumah Sakit/Klinik,Kota,Jumlah Mahasiswa Terpilih\n" +
                  "RS Pertamedika,Banda Aceh,24 Mahasiswa\n" +
                  "RSUD Dr. Zainoel Abidin,Banda Aceh,40 Mahasiswa\n" +
                  "Puskesmas Baiturrahman,Banda Aceh,12 Mahasiswa\n" +
                  "==================================================\n" +
                  "Status Penempatan: Berjalan Lancar.";
    } else {
        isiFile = "JUDUL LAPORAN: " + namaLaporan + "\n" +
                  "Dibuat: 10 Mei 2025\n" +
                  "Oleh: Admin STIKES MNI\n" +
                  "==================================================\n" +
                  "No,NIM,Nama Calon Wisudawan,Yudisium,Predikat\n" +
                  "1,1021044,Rina Citra,Lulus,Dengan Pujian (Cumlaude)\n" +
                  "2,1021089,Dedi Wijaya,Lulus,Sangat Memuaskan\n" +
                  "==================================================\n" +
                  "Total Wisudawan Periode II: 112 Mahasiswa.";
    }

    // Mengonversi string teks menjadi blob file siap unduh
    const blob = new Blob([isiFile], { type: "text/plain;charset=utf-8" });
    const linkUnduh = document.createElement("a");
    
    // Menamai file sesuai nama laporan yang dipilih
    linkUnduh.download = namaLaporan.toLowerCase().replace(/ /g, "_") + ".txt";
    linkUnduh.href = window.URL.createObjectURL(blob);
    linkUnduh.style.display = "none";
    
    document.body.appendChild(linkUnduh);
    linkUnduh.click();
    document.body.removeChild(linkUnduh);
}
</script>