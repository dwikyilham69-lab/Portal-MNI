<?php
$praktik = get_praktik();
?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />

<div class="page-header">
  <div class="page-header-left"><h2>🏥 Praktik Klinik</h2><p>Data lokasi dan penempatan praktik mahasiswa</p></div>
  <div style="display:flex;gap:8px">
    <a href="#areaPetaKlinik" class="btn-secondary" style="text-decoration:none; display:inline-flex; align-items:center;">🗺️ Peta Lokasi</a>
    <button class="btn-primary" onclick="alert('Form tambah lokasi praktik')">➕ Tambah Lokasi</button>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card teal"  style="padding:16px 18px"><div class="stat-icon teal"  style="margin-bottom:8px">🏥</div><div class="stat-value" style="font-size:26px">34</div><div class="stat-label">Total Lokasi</div></div>
  <div class="stat-card green" style="padding:16px 18px"><div class="stat-icon green" style="margin-bottom:8px">✅</div><div class="stat-value" style="font-size:26px">28</div><div class="stat-label">Aktif</div></div>
  <div class="stat-card gold"  style="padding:16px 18px"><div class="stat-icon gold"  style="margin-bottom:8px">👨‍⚕️</div><div class="stat-value" style="font-size:26px">412</div><div class="stat-label">Mahasiswa Praktik</div></div>
  <div class="stat-card blue"  style="padding:16px 18px"><div class="stat-icon blue"  style="margin-bottom:8px">📋</div><div class="stat-value" style="font-size:26px">89%</div><div class="stat-label">Laporan Terisi</div></div>
</div>

<div class="card" id="areaPetaKlinik" style="margin-bottom:20px;">
  <div class="card-header"><div class="card-title"><span>🗺️</span> Peta Sebaran Lokasi Praktik Klinik</div></div>
  <div class="card-body" style="padding:12px;">
    <div id="map" style="width:100%; height:400px; border-radius:8px; z-index:1;"></div>
  </div>
</div>

<div class="two-col">
  <div class="card">
    <div class="card-header"><div class="card-title"><span>🏥</span> Daftar Lokasi Praktik</div></div>
    <div class="card-body">
      <table class="data-table">
        <thead><tr><th>Nama Instansi</th><th>Kota</th><th>Tipe</th><th>Mhs</th><th>Supervisor</th><th>Periode</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($praktik as $pk): ?>
          <tr>
            <td><strong style="font-size:13px"><?= h($pk['nama']) ?></strong></td>
            <td><?= h($pk['kota']) ?></td>
            <td><span class="badge <?= h($pk['tipe_badge']) ?>"><?= h($pk['tipe']) ?></span></td>
            <td style="font-family:'DM Mono',monospace;font-weight:600"><?= $pk['mhs'] ?></td>
            <td style="font-size:12px;color:var(--text-light)"><?= h($pk['supervisor']) ?></td>
            <td style="font-size:11px"><?= h($pk['periode']) ?></td>
            <td><?= status_badge($pk['status']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div>
    <div class="card" style="margin-bottom:16px">
      <div class="card-header"><div class="card-title"><span>📊</span> Sebaran Lokasi</div></div>
      <div class="card-body">
        <?php
        $tipe_data = [
            ['label'=>'🏥 Rumah Sakit','jml'=>'14 lokasi','pct'=>82,'cls'=>'teal'],
            ['label'=>'🏢 Puskesmas',  'jml'=>'12 lokasi','pct'=>70,'cls'=>'gold'],
            ['label'=>'🏪 Klinik',     'jml'=>'8 lokasi', 'pct'=>47,'cls'=>'blue'],
        ];
        ?>
        <div style="display:flex;flex-direction:column;gap:10px">
        <?php foreach ($tipe_data as $td): ?>
          <div>
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <span style="font-size:13px;color:var(--text-mid)"><?= $td['label'] ?></span>
              <span style="font-family:'DM Mono',monospace;font-size:12px;font-weight:600"><?= $td['jml'] ?></span>
            </div>
            <div class="progress-bar"><div class="progress-fill <?= $td['cls'] ?>" style="width:<?= $td['pct'] ?>%"></div></div>
          </div>
        <?php endforeach; ?>
        </div>
        <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border)">
          <div style="font-size:12px;font-weight:600;color:var(--text-mid);margin-bottom:10px">Sebaran Kota</div>
          <div style="display:flex;flex-wrap:wrap;gap:8px">
            <span class="badge badge-teal">Banda Aceh (14)</span>
            <span class="badge badge-gold">Sigli (8)</span>
            <span class="badge badge-blue">Medan (5)</span>
            <span class="badge badge-green">Lhokseumawe (4)</span>
            <span class="badge badge-purple">Lainnya (3)</span>
          </div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title"><span>📋</span> Laporan Tertunda</div></div>
      <div class="card-body">
        <div class="alert-list">
          <div class="alert-item warn"><div class="alert-icon">⚠️</div><div><div class="alert-title">23 Laporan Belum Dikumpul</div><div class="alert-desc">RS Pertamedika · Tenggat 30 Juni</div></div></div>
          <div class="alert-item info"><div class="alert-icon">📄</div><div><div class="alert-title">Verifikasi Supervisor Pending</div><div class="alert-desc">Puskesmas Garot · 8 mahasiswa</div></div></div>
          <div class="alert-item success"><div class="alert-icon">✅</div><div><div class="alert-title">Laporan RSUD ZA Lengkap</div><div class="alert-desc">48 mahasiswa sudah mengumpulkan</div></div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // 1. Inisialisasi Peta (Koordinat awal berpusat di area Aceh/Sumatera Utara)
    const map = L.map('map').setView([5.54829, 95.32375], 7);

    // 2. Memuat aset tiles desain peta dari OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // 3. Menyiapkan Data Kordinat Dummy Lokasi Praktik (Sesuai list sebaran kota Anda)
    const lokasiKlinik = [
        { nama: "RSUD Dr. Zainoel Abidin", kota: "Banda Aceh", tipe: "Rumah Sakit", koordinat: [5.5601, 95.3374], mhs: 48 },
        { nama: "RS Pertamedika", kota: "Banda Aceh", tipe: "Rumah Sakit", koordinat: [5.5512, 95.3190], mhs: 23 },
        { nama: "Puskesmas Garot", kota: "Sigli", tipe: "Puskesmas", koordinat: [5.3831, 95.9592], mhs: 8 },
        { nama: "Rumah Sakit Malahayati", kota: "Banda Aceh", tipe: "Rumah Sakit", koordinat: [5.5530, 95.3220], mhs: 14 },
        { nama: "Klinik Sehat Bersama", kota: "Medan", tipe: "Klinik", koordinat: [3.5952, 98.6722], mhs: 5 },
        { nama: "Puskesmas Baiturrahman", kota: "Banda Aceh", tipe: "Puskesmas", koordinat: [5.5458, 95.3164], mhs: 12 },
        { nama: "RSUD Cut Meutia", kota: "Lhokseumawe", koordinat: [5.1416, 97.1472], tipe: "Rumah Sakit", mhs: 4 }
    ];

    // 4. Meletakkan penanda (Marker) ke peta secara otomatis
    lokasiKlinik.forEach(function(klinik) {
        const popupText = `
            <div style="font-family: sans-serif; font-size:13px; line-height:1.4;">
                <strong style="color:#0d6e6e; font-size:14px;">${klinik.nama}</strong><br>
                <b>Wilayah:</b> ${klinik.kota}<br>
                <b>Tipe:</b> ${klinik.tipe}<br>
                <b>Aktif Praktik:</b> <span style="background:#e8f5f5; padding:2px 6px; border-radius:4px; font-weight:bold; color:#0d6e6e;">${klinik.mhs} Mahasiswa</span>
            </div>
        `;

        L.marker(klinik.koordinat)
         .addTo(map)
         .bindPopup(popupText);
    });
});
</script>