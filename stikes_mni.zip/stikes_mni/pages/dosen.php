<?php
$dosen = get_dosen();
?>
<div class="page-header">
  <div class="page-header-left"><h2>👨‍🏫 Data Dosen</h2><p>Manajemen sumber daya pengajar STIKES MNI</p></div>
  <div style="display:flex;gap:8px">
    <button class="btn-secondary">⬇️ Ekspor</button>
    <button class="btn-primary" onclick="alert('Form tambah dosen')">➕ Tambah Dosen</button>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card teal" style="padding:16px 18px"><div class="stat-icon teal" style="margin-bottom:8px">📚</div><div class="stat-value" style="font-size:26px">72</div><div class="stat-label">Aktif Mengajar</div></div>
  <div class="stat-card gold" style="padding:16px 18px"><div class="stat-icon gold" style="margin-bottom:8px">🏆</div><div class="stat-value" style="font-size:26px">18</div><div class="stat-label">Doktor (S3)</div></div>
  <div class="stat-card green" style="padding:16px 18px"><div class="stat-icon green" style="margin-bottom:8px">🎓</div><div class="stat-value" style="font-size:26px">54</div><div class="stat-label">Magister (S2)</div></div>
  <div class="stat-card blue" style="padding:16px 18px"><div class="stat-icon blue" style="margin-bottom:8px">📝</div><div class="stat-value" style="font-size:26px">15</div><div class="stat-label">Sertifikasi Aktif</div></div>
</div>

<div class="two-col-equal">
  <!-- Distribusi per Prodi -->
  <div class="card">
    <div class="card-header"><div class="card-title"><span>👥</span> Dosen per Prodi</div></div>
    <div class="card-body">
      <?php
      $prodi_dosen = [
          ['nama'=>'Keperawatan','jml'=>28,'pct'=>68,'cls'=>'teal'],
          ['nama'=>'Kebidanan',  'jml'=>18,'pct'=>44,'cls'=>'gold'],
          ['nama'=>'Farmasi',    'jml'=>16,'pct'=>39,'cls'=>'blue'],
          ['nama'=>'Kesehatan Masyarakat.','jml'=>14,'pct'=>34,'cls'=>'green'],
          ['nama'=>'Profesi Ners','jml'=>11,'pct'=>27,'cls'=>''],
      ];
      ?>
      <div style="display:flex;flex-direction:column;gap:12px">
      <?php foreach ($prodi_dosen as $pd): ?>
        <div>
          <div style="display:flex;justify-content:space-between;margin-bottom:4px">
            <span style="font-size:13px;color:var(--text-mid)"><?= h($pd['nama']) ?></span>
            <span style="font-family:'DM Mono',monospace;font-size:12px;font-weight:600"><?= $pd['jml'] ?> dosen</span>
          </div>
          <div class="progress-bar">
            <div class="progress-fill <?= $pd['cls'] ?>" style="width:<?= $pd['pct'] ?>%;<?= !$pd['cls'] ? 'background:linear-gradient(90deg,#7350b8,var(--purple-soft))' : '' ?>"></div>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Dosen Berprestasi -->
  <div class="card">
    <div class="card-header"><div class="card-title"><span>⭐</span> Dosen Berprestasi</div></div>
    <div class="card-body">
      <table class="data-table">
        <thead><tr><th>Nama</th><th>Jabatan</th><th>MK</th><th>Rating</th></tr></thead>
        <tbody>
        <?php foreach (array_slice($dosen, 0, 4) as $d): ?>
          <tr>
            <td><div class="avatar-cell">
              <div class="avatar-sm" style="background:<?= h($d['color']) ?>;color:<?= h($d['tc']) ?>"><?= h($d['inisial']) ?></div>
              <span class="name-cell"><?= h($d['nama']) ?></span>
            </div></td>
            <td><?= jabatan_badge($d['jabatan']) ?></td>
            <td><?= $d['mk'] ?></td>
            <td style="color:var(--gold);font-weight:600">★ <?= number_format($d['rating'],1) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Direktori Dosen -->
<div class="card">
  <div class="card-header"><div class="card-title"><span>👤</span> Direktori Dosen</div></div>
  <div class="card-body">
    <div class="dosen-grid">
    <?php foreach ($dosen as $d): ?>
      <div class="dosen-card" onclick="alert('Detail <?= h($d["nama"]) ?>')">
        <div class="dosen-avatar" style="background:<?= h($d['color']) ?>;color:<?= h($d['tc']) ?>"><?= h($d['inisial']) ?></div>
        <div class="dosen-name"><?= h($d['nama']) ?></div>
        <div class="dosen-prodi"><?= h($d['prodi']) ?> · <?= h($d['jabatan']) ?></div>
        <?= status_badge($d['status']) ?>
      </div>
    <?php endforeach; ?>
    </div>
  </div>
</div>
