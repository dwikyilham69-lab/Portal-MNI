<?php
$transaksi = get_transaksi();
$stats = get_stats();
?>
<div class="page-header">
  <div class="page-header-left"><h2>💰 Data Keuangan</h2><p>Laporan keuangan dan pembayaran semester</p></div>
  <div style="display:flex;gap:8px">
    <button class="btn-secondary" onclick="window.print()">📄 Cetak Laporan</button>
    <button class="btn-primary" onclick="alert('Form catat transaksi')">➕ Catat Transaksi</button>
  </div>
</div>

<div class="finance-summary">
  <div class="finance-card">
    <div class="finance-card-label">Total Pemasukan Tahun Ini</div>
    <div class="finance-card-value">Rp <?= $stats['pendapatan_tahun'] ?></div>
    <div class="finance-card-change" style="color:var(--green-soft)">↑ +12% dari tahun lalu</div>
  </div>
  <div class="finance-card">
    <div class="finance-card-label">Total Pengeluaran Tahun Ini</div>
    <div class="finance-card-value">Rp <?= $stats['pengeluaran_tahun'] ?></div>
    <div class="finance-card-change" style="color:var(--red-soft)">↑ +5% dari tahun lalu</div>
  </div>
  <div class="finance-card">
    <div class="finance-card-label">Saldo Bersih</div>
    <div class="finance-card-value" style="color:var(--teal-mid)">Rp <?= $stats['saldo_bersih'] ?></div>
    <div class="finance-card-change" style="color:var(--green-soft)">Surplus tahun ini</div>
  </div>
</div>

<div class="two-col-equal">
  <div class="card">
    <div class="card-header"><div class="card-title"><span>📈</span> Tren Keuangan 6 Bulan</div></div>
    <div class="card-body">
      <div class="bar-chart-wrap" id="fin-chart-k" style="height:140px"></div>
      <div class="chart-labels">
        <?php foreach (['Jan','Feb','Mar','Apr','Mei','Jun'] as $m): ?>
        <div class="chart-label" style="flex:1;text-align:center"><?= $m ?></div>
        <?php endforeach; ?>
      </div>
      <div style="display:flex;gap:16px;margin-top:10px">
        <div style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text-light)"><div style="width:10px;height:10px;background:var(--teal-mid);border-radius:2px"></div>Pemasukan</div>
        <div style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text-light)"><div style="width:10px;height:10px;background:var(--gold);border-radius:2px"></div>Pengeluaran</div>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header"><div class="card-title"><span>🎯</span> Status Pembayaran SPP</div></div>
    <div class="card-body">
      <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:16px">
        <div><div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:13px;color:var(--text-mid)">✅ Lunas</span><span style="font-family:'DM Mono',monospace;font-size:12px;font-weight:600">924 mhs (74%)</span></div><div class="progress-bar"><div class="progress-fill green" style="width:74%"></div></div></div>
        <div><div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:13px;color:var(--text-mid)">⏳ Cicilan</span><span style="font-family:'DM Mono',monospace;font-size:12px;font-weight:600">198 mhs (16%)</span></div><div class="progress-bar"><div class="progress-fill gold" style="width:16%"></div></div></div>
        <div><div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:13px;color:var(--text-mid)">❌ Belum Bayar</span><span style="font-family:'DM Mono',monospace;font-size:12px;font-weight:600">126 mhs (10%)</span></div><div class="progress-bar"><div class="progress-fill red" style="width:10%"></div></div></div>
      </div>
      <div style="background:var(--cream);border-radius:var(--radius-sm);padding:12px;border:1px solid var(--border)">
        <div style="font-size:11px;color:var(--text-light);margin-bottom:6px">Total SPP Terkumpul Semester Ini</div>
        <div style="font-family:'Playfair Display',serif;font-size:22px;color:var(--teal-deep)">Rp 12,4M</div>
        <div style="font-size:11px;color:var(--green-soft);margin-top:2px">dari target Rp 14,9M (83%)</div>
      </div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title"><span>📑</span> Transaksi Terbaru</div>
    <div style="display:flex;gap:8px;align-items:center">
      <div class="filter-bar" style="margin:0">
        <button class="filter-btn active">Semua</button>
        <button class="filter-btn" onclick="toggleFilter(this)">Masuk</button>
        <button class="filter-btn" onclick="toggleFilter(this)">Keluar</button>
      </div>
    </div>
  </div>
  <div class="card-body">
    <table class="data-table">
      <thead><tr><th>Tanggal</th><th>Deskripsi</th><th>Kategori</th><th>Metode</th><th>Nominal</th><th>Tipe</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($transaksi as $t): ?>
        <tr>
          <td style="font-family:'DM Mono',monospace;font-size:12px"><?= h($t['tanggal']) ?></td>
          <td>
            <strong style="font-size:13px"><?= h($t['deskripsi']) ?></strong>
            <br><span style="font-size:11px;color:var(--text-light)"><?= h($t['sub']) ?></span>
          </td>
          <td><span class="badge <?= h($t['cat_badge']) ?>"><?= h($t['kategori']) ?></span></td>
          <td style="font-size:12px"><?= h($t['metode']) ?></td>
          <td style="font-family:'DM Mono',monospace;font-weight:600;color:<?= str_contains($t['nominal'],'+') ? 'var(--green-soft)' : 'var(--red-soft)' ?>">
            <?= h($t['nominal']) ?>
          </td>
          <td><span class="badge <?= h($t['tipe_badge']) ?>"><?= h($t['tipe']) ?></span></td>
          <td><button onclick="alert('Detail transaksi')" style="background:none;border:none;cursor:pointer;font-size:14px">👁️</button></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<script>document.addEventListener('DOMContentLoaded',function(){if(document.getElementById('fin-chart-k'))drawChart('fin-chart-k',110);});</script>
