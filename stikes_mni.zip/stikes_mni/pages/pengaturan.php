?>
<div class="page-header">
  <div class="page-header-left"><h2>⚙️ Pengaturan</h2><p>Konfigurasi sistem informasi akademik</p></div>
  <button class="btn-primary" onclick="alert('Pengaturan disimpan')">💾 Simpan Perubahan</button>
</div>
<div class="two-col-equal">
  <div class="card">
    <div class="card-header"><div class="card-title"><span>🏫</span> Informasi Institusi</div></div>
    <div class="card-body">
      <?php
      $fields = [
          ['label'=>'Nama Institusi','val'=>'STIKES Medika Nurul Islam'],
          ['label'=>'Singkatan',     'val'=>'STIKES MNI'],
          ['label'=>'Alamat',        'val'=>'Jl. Banda Aceh, Aceh'],
          ['label'=>'Email',         'val'=>'info@stikesmni.ac.id'],
          ['label'=>'Telepon',       'val'=>'+62 651 XXXXXX'],
          ['label'=>'Semester Aktif','val'=>'Genap 2025/2026'],
      ];
      foreach ($fields as $f): ?>
      <div style="margin-bottom:14px">
        <label style="font-size:12px;font-weight:500;color:var(--text-mid);display:block;margin-bottom:5px"><?= h($f['label']) ?></label>
        <input type="text" value="<?= h($f['val']) ?>" style="width:100%;padding:10px 13px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;font-family:'DM Sans',sans-serif;color:var(--text-dark);background:var(--cream);outline:none">
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <div>
    <div class="card" style="margin-bottom:16px">
      <div class="card-header"><div class="card-title"><span>👤</span> Profil Pengguna</div></div>
      <div class="card-body">
        <div style="text-align:center;margin-bottom:16px">
          <div class="user-avatar" style="width:64px;height:64px;font-size:24px;margin:0 auto 10px;border-radius:50%;background:linear-gradient(135deg,var(--gold),var(--gold-light));display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--teal-deep)">
            <?= strtoupper(substr($_SESSION['user']['name'],0,1)) ?>
          </div>
          <div style="font-weight:600;color:var(--text-dark)"><?= h($_SESSION['user']['name']) ?></div>
          <div style="font-size:12px;color:var(--text-light)"><?= h($_SESSION['user']['role']) ?></div>
        </div>
        <div style="margin-bottom:12px">
          <label style="font-size:12px;font-weight:500;color:var(--text-mid);display:block;margin-bottom:5px">Kata Sandi Baru</label>
          <input type="password" placeholder="••••••••" style="width:100%;padding:10px 13px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;font-family:'DM Sans',sans-serif;outline:none;background:var(--cream)">
        </div>
        <button class="btn-secondary" style="width:100%;justify-content:center">🔐 Ubah Kata Sandi</button>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title"><span>🔔</span> Notifikasi</div></div>
      <div class="card-body">
        <?php
        $notifs = ['Email untuk laporan baru','Pengingat tenggat KRS','Notifikasi pembayaran SPP','Update jadwal kuliah'];
        foreach ($notifs as $n): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid rgba(200,232,230,0.5)">
          <span style="font-size:13px;color:var(--text-mid)"><?= h($n) ?></span>
          <div style="width:36px;height:20px;background:var(--teal-mid);border-radius:20px;position:relative;cursor:pointer">
            <div style="width:14px;height:14px;background:white;border-radius:50%;position:absolute;top:3px;right:3px;transition:0.2s"></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
