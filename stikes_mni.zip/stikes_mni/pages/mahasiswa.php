<?php
$filter = isset($_GET['prodi']) ? $_GET['prodi'] : 'semua';
$search = isset($_GET['q']) ? strtolower($_GET['q']) : '';
$all_mhs = get_mahasiswa($filter);
if ($search) {
    $all_mhs = array_filter($all_mhs, fn($m) =>
        str_contains(strtolower($m['nama']), $search) ||
        str_contains(strtolower($m['nim']), $search)
    );
}
$stats = get_stats();
$prodis = ['semua', 'Keperawatan', 'Kebidanan', 'Farmasi', 'Kesehatan Masyarakats', 'Profesi Ners'];
?>

<div class="page-header">
  <div class="page-header-left"><h2>🎓 Data Mahasiswa</h2><p>Manajemen data seluruh mahasiswa STIKES MNI</p></div>
  <div style="display:flex;gap:8px">
    <a href="?page=mahasiswa&export=1" class="btn-secondary">⬇️ Ekspor CSV</a>
    <button class="btn-primary" onclick="alert('Form tambah mahasiswa akan tampil di sini')">➕ Tambah Mahasiswa</button>
  </div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <div class="stat-card teal" style="padding:16px 18px"><div class="stat-icon teal" style="margin-bottom:8px">✅</div><div class="stat-value" style="font-size:26px"><?= $stats['mahasiswa_aktif'] ?></div><div class="stat-label">Aktif</div></div>
  <div class="stat-card gold" style="padding:16px 18px"><div class="stat-icon gold" style="margin-bottom:8px">⏸️</div><div class="stat-value" style="font-size:26px"><?= $stats['mahasiswa_cuti'] ?></div><div class="stat-label">Cuti</div></div>
  <div class="stat-card green" style="padding:16px 18px"><div class="stat-icon green" style="margin-bottom:8px">🎓</div><div class="stat-value" style="font-size:26px"><?= $stats['mahasiswa_lulus'] ?></div><div class="stat-label">Lulus</div></div>
  <div class="stat-card blue" style="padding:16px 18px"><div class="stat-icon blue" style="margin-bottom:8px">❌</div><div class="stat-value" style="font-size:26px"><?= $stats['mahasiswa_do'] ?></div><div class="stat-label">Drop Out</div></div>
</div>

<div class="card">
  <div class="card-header" style="padding:16px 22px;flex-wrap:wrap;gap:12px">
    <div class="filter-bar" style="margin:0;flex-wrap:wrap">
      <?php foreach ($prodis as $p): ?>
        <a href="?page=mahasiswa&prodi=<?= urlencode($p) ?>" class="filter-btn <?= $filter === $p ? 'active' : '' ?>">
          <?= $p === 'semua' ? 'Semua' : h($p) ?>
        </a>
      <?php endforeach; ?>
    </div>
    <form method="get" action="index.php" style="display:flex;gap:6px;margin-left:auto">
      <input type="hidden" name="page" value="mahasiswa">
      <input type="hidden" name="prodi" value="<?= h($filter) ?>">
      <input type="text" name="q" placeholder="Cari nama / NIM..." value="<?= h($_GET['q'] ?? '') ?>"
             style="padding:7px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;outline:none;font-family:'DM Sans',sans-serif;width:200px">
      <button type="submit" class="btn-primary" style="padding:7px 14px">Cari</button>
    </form>
  </div>
  <div class="card-body" style="padding-top:0">
    <table class="data-table">
      <thead><tr><th>#</th><th>Nama Mahasiswa</th><th>NIM</th><th>Prodi</th><th>Semester</th><th>Angkatan</th><th>IPK</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php if (empty($all_mhs)): ?>
        <tr><td colspan="9" style="text-align:center;padding:30px;color:var(--text-light)">Tidak ada data ditemukan</td></tr>
      <?php else: ?>
        <?php foreach ($all_mhs as $m): ?>
        <tr>
          <td><?= $m['no'] ?></td>
          <td><div class="avatar-cell">
            <div class="avatar-sm" style="background:<?= h($m['color']) ?>;color:<?= h($m['tc']) ?>"><?= h($m['inisial']) ?></div>
            <div>
              <div class="name-cell"><?= h($m['nama']) ?></div>
              <div style="font-size:10px;color:var(--text-light)"><?= h($m['email']) ?></div>
            </div>
          </div></td>
          <td style="font-family:'DM Mono',monospace;font-size:12px"><?= h($m['nim']) ?></td>
          <td><?= prodi_badge($m['prodi']) ?></td>
          <td><?= h($m['smt']) ?></td>
          <td><?= $m['angkatan'] ?></td>
          <td style="font-family:'DM Mono',monospace;font-weight:600;color:<?= ipk_color($m['ipk']) ?>">
            <?= $m['ipk'] !== null ? number_format($m['ipk'], 2) : '—' ?>
          </td>
          <td><?= status_badge($m['status']) ?></td>
          <td>
            <button onclick="alert('Edit <?= h($m['nama']) ?>')" style="background:none;border:none;cursor:pointer;font-size:14px" title="Edit">✏️</button>
            <button onclick="return confirm('Hapus <?= h($m['nama']) ?>?')" style="background:none;border:none;cursor:pointer;font-size:14px" title="Hapus">🗑️</button>
          </td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
    <div style="display:flex;justify-content:space-between;align-items:center;padding-top:16px;font-size:12px;color:var(--text-light)">
      <span>Menampilkan <?= count($all_mhs) ?> dari <?= number_format($stats['total_mahasiswa']) ?> mahasiswa</span>
      <div style="display:flex;gap:6px">
        <button class="filter-btn">‹ Prev</button>
        <button class="filter-btn active">1</button>
        <button class="filter-btn">2</button>
        <button class="filter-btn">3</button>
        <button class="filter-btn">Next ›</button>
      </div>
    </div>
  </div>
</div>
