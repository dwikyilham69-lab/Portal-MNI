// ── Login page: fill demo credentials
function fillDemo(user, pass, btn) {
  document.querySelectorAll('.role-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  var u = document.getElementById('username');
  var p = document.getElementById('password');
  if (u) u.value = user;
  if (p) p.value = pass;
}

// ── Finance chart renderer
var pemasukan   = [3.2, 4.1, 3.8, 4.5, 3.9, 4.2];
var pengeluaran = [2.8, 3.1, 2.9, 3.3, 2.7, 3.0];

function drawChart(containerId, maxH) {
  var c = document.getElementById(containerId);
  if (!c) return;
  c.innerHTML = '';
  var maxVal = Math.max.apply(null, pemasukan.concat(pengeluaran)) * 1.1;
  pemasukan.forEach(function(p, i) {
    var grp = document.createElement('div');
    grp.className = 'bar-group';
    var b1 = document.createElement('div');
    b1.className = 'bar-col';
    b1.style.cssText = 'height:' + ((p/maxVal)*maxH) + 'px;background:#0d6e6e;opacity:0.85;border-radius:4px 4px 0 0;transition:height 1s ease ' + (i*0.1) + 's;';
    b1.title = 'Pemasukan: Rp ' + p + 'M';
    var b2 = document.createElement('div');
    b2.className = 'bar-col';
    b2.style.cssText = 'height:' + ((pengeluaran[i]/maxVal)*maxH) + 'px;background:#c9923a;opacity:0.75;border-radius:4px 4px 0 0;transition:height 1s ease ' + (i*0.1+0.05) + 's;';
    b2.title = 'Pengeluaran: Rp ' + pengeluaran[i] + 'M';
    grp.appendChild(b1);
    grp.appendChild(b2);
    c.appendChild(grp);
  });
}

// ── Filter button toggle
function toggleFilter(btn) {
  btn.classList.toggle('active');
}

// ── Init on DOM ready
document.addEventListener('DOMContentLoaded', function() {
  // Draw finance charts on dashboard
  if (document.getElementById('fin-chart')) {
    drawChart('fin-chart', 130);
  }
  // Animate progress bars
  document.querySelectorAll('.progress-fill').forEach(function(bar) {
    var w = bar.style.width;
    bar.style.width = '0';
    setTimeout(function() { bar.style.width = w; }, 200);
  });
});
